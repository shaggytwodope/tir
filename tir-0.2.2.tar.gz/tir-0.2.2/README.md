TIR - Terminal Image Renderer
=============================

A little tool I wrote to get in touch with golang.
It renders a given jpg or png in 256 colors on your terminal.

![screenshot](https://raw.github.com/ikaros/tir/master/doc/screenshot.png)




